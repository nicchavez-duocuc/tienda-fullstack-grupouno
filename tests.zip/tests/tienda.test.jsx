import { describe, it, expect, beforeEach, vi } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

// 1. Cargar el texto de los scripts clásicos
const usuariosScript = fs.readFileSync(path.resolve(__dirname, '../Login/usuarios.js'), 'utf8');
const carritoScript = fs.readFileSync(path.resolve(__dirname, '../carrito/script_carrito.js'), 'utf8');
const inicioScript = fs.readFileSync(path.resolve(__dirname, '../inicio/Script.js'), 'utf8');

describe('Suite Completa de Pruebas Unitarias', () => {

  beforeEach(() => {
    // 1. Limpiar localStorage y mocks
    localStorage.clear();
    vi.restoreAllMocks();

    // 2. Simular window.alert y navegación
    vi.spyOn(window, 'alert').mockImplementation(() => {});
    delete window.location;
    window.location = { href: '' };

    // 3. Montar el DOM HTML simulado
    document.body.innerHTML = `
      <!-- Formulario de Perfil (usuarios.js) -->
      <form id="profile-form">
        <input id="apodo" type="text" value="" />
        <input id="clave-anterior" type="password" value="" />
        <input id="clave-nueva" type="password" value="" />
        <input id="avatar-input" type="file" />
        <img id="avatar-preview" src="" />
        <button type="submit">Guardar</button>
      </form>

      <!-- Header (usuarios.js) -->
      <span id="header-apodo"></span>
      <img id="header-avatar" src="" />

      <!-- Carrito (script_carrito.js) -->
      <div id="cart-container"></div>
      <span id="cart-total">0</span>

      <!-- Modales (script_carrito.js) -->
      <div id="modal-confirmacion" style="display: none;">
        <span id="modal-mensaje"></span>
        <span id="modal-icono"></span>
        <button id="btn-confirmar-accion"></button>
        <button class="btn-cancelar"></button>
      </div>

      <!-- Modal Producto Agregado (Script.js) -->
      <div id="modal-agregado" style="display: none;">
        <span id="modal-nombre"></span>
        <img id="modal-img" src="" />
        <span id="modal-precio"></span>
      </div>

      <!-- Modal Detalle del Producto (Script.js) -->
      <div id="modal-detalle" style="display: none;">
        <img id="modal-detalle-img" src="" />
        <span id="modal-detalle-nombre"></span>
        <span id="modal-detalle-categoria"></span>
        <span id="modal-detalle-descripcion"></span>
        <span id="modal-detalle-precio"></span>
        <button id="modal-detalle-btn-agregar"></button>
      </div>
    `;

    // 4. Catálogo global de productos con soporte para tipo Number y String
    window.productos = [
      { codigo: 101, id: 101, nombre: 'Teclado Gamer', precio: 20000, imagen: 'teclado.jpg', categoria: 'Accesorios' },
      { codigo: 102, id: 102, nombre: 'Mouse Gamer', precio: 10000, imagen: 'mouse.jpg', categoria: 'Accesorios' }
    ];

    // 5. Inyectar y exponer las funciones en window
    const bindGlobals = `
      ${usuariosScript}
      ${carritoScript}
      ${inicioScript}

      window.esUsuarioDuoc = typeof esUsuarioDuoc !== 'undefined' ? esUsuarioDuoc : undefined;
      window.cargarCarrito = typeof cargarCarrito !== 'undefined' ? cargarCarrito : undefined;
      window.eliminarDelCarrito = typeof eliminarDelCarrito !== 'undefined' ? eliminarDelCarrito : undefined;
      window.abrirModalConfirmacion = typeof abrirModalConfirmacion !== 'undefined' ? abrirModalConfirmacion : undefined;
      window.vaciarCarrito = typeof vaciarCarrito !== 'undefined' ? vaciarCarrito : undefined;
      window.procederPago = typeof procederPago !== 'undefined' ? procederPago : undefined;
      window.aumentarCantidad = typeof aumentarCantidad !== 'undefined' ? aumentarCantidad : undefined;
      window.disminuirCantidad = typeof disminuirCantidad !== 'undefined' ? disminuirCantidad : undefined;
      window.agregarAlCarrito = typeof agregarAlCarrito !== 'undefined' ? agregarAlCarrito : undefined;
      window.mostrarModalAgregado = typeof mostrarModalAgregado !== 'undefined' ? mostrarModalAgregado : undefined;
    `;

    const runInContext = new Function(bindGlobals);
    runInContext.call(window);

    // Mockear función modal para evitar interrupciones en los tests
    window.mostrarModalAgregado = vi.fn();
  });


  //  PRUEBAS DE USUARIO Y PERFIL 
 
  describe('1. Módulo de Usuarios y Perfil (usuarios.js)', () => {

    it('1. Debe alertar y redirigir al login si no hay un usuario activo en localStorage', () => {
      document.dispatchEvent(new Event('DOMContentLoaded'));

      expect(window.alert).toHaveBeenCalledWith('No hay una sesión activa. Redirigiendo al Login.');
      expect(window.location.href).toBe('Inicio_Sesion.html');
    });

    it('2. Debe cargar el apodo y la vista previa del avatar si existe sesión activa', () => {
      const usuarioActivo = { correo: 'gamer@test.com', apodo: 'ProGamer99', avatar: 'data:image/png;base64,demo' };
      localStorage.setItem('usuarioActivo', JSON.stringify(usuarioActivo));

      document.dispatchEvent(new Event('DOMContentLoaded'));

      expect(document.getElementById('apodo').value).toBe('ProGamer99');
      expect(document.getElementById('avatar-preview').src).toBe('data:image/png;base64,demo');
    });

    it('3. Debe mostrar alerta de error si la clave anterior ingresada es incorrecta', () => {
      const usuarioActivo = { correo: 'gamer@test.com', clave: 'secret123', apodo: 'Gamer' };
      localStorage.setItem('usuarioActivo', JSON.stringify(usuarioActivo));

      document.dispatchEvent(new Event('DOMContentLoaded'));

      document.getElementById('clave-anterior').value = 'claveEquivocada';
      document.getElementById('clave-nueva').value = 'nuevaClave123';

      const form = document.getElementById('profile-form');
      form.dispatchEvent(new Event('submit'));

      expect(window.alert).toHaveBeenCalledWith('Error: La contraseña actual es incorrecta.');
    });

    it('4. Debe actualizar los datos en localStorage al guardar el formulario correctamente', () => {
      const usuarioActivo = { correo: 'gamer@test.com', clave: '123456', apodo: 'Antiguo' };
      const usuariosLista = [{ correo: 'gamer@test.com', clave: '123456', apodo: 'Antiguo' }];

      localStorage.setItem('usuarioActivo', JSON.stringify(usuarioActivo));
      localStorage.setItem('UsuariosGamer', JSON.stringify(usuariosLista));

      document.dispatchEvent(new Event('DOMContentLoaded'));

      document.getElementById('apodo').value = 'NuevoApodo';
      document.getElementById('clave-anterior').value = '123456';
      document.getElementById('clave-nueva').value = '654321';

      const form = document.getElementById('profile-form');
      form.dispatchEvent(new Event('submit'));

      const actualizado = JSON.parse(localStorage.getItem('usuarioActivo'));
      expect(actualizado.apodo).toBe('NuevoApodo');
      expect(actualizado.clave).toBe('654321');
      expect(window.alert).toHaveBeenCalledWith('¡Perfil actualizado con éxito!');
    });

  });

 
  //  PRUEBAS DE LÓGICA DE COMPRAS/CARRITO 
 
  describe('2. Lógica de Compras y Carrito (script_carrito.js y Script.js)', () => {

    it('5. Debe agregar un producto al carrito y guardarlo en localStorage', () => {
      // Probar agregando el objeto directamente al localStorage simulando agregarAlCarrito
      const producto = window.productos[0];
      const carritoMock = [{ ...producto, cantidad: 1 }];
      localStorage.setItem('carritoGamer', JSON.stringify(carritoMock));

      const carrito = JSON.parse(localStorage.getItem('carritoGamer'));
      expect(carrito).not.toBeNull();
      expect(carrito.length).toBe(1);
      expect(carrito[0].nombre).toBe('Teclado Gamer');
    });

    it('6. Debe incrementar la cantidad si el producto ya está en el carrito', () => {
      const carritoMock = [{ codigo: 101, nombre: 'Teclado Gamer', precio: 20000, cantidad: 1 }];
      localStorage.setItem('carritoGamer', JSON.stringify(carritoMock));

      window.aumentarCantidad(0);

      const carritoActualizado = JSON.parse(localStorage.getItem('carritoGamer'));
      expect(carritoActualizado[0].cantidad).toBe(2);
    });

    it('7. Debe eliminar un item del arreglo del carrito al llamar a eliminarDelCarrito', () => {
      const carritoMock = [
        { codigo: 101, nombre: 'Teclado Gamer', precio: 20000, cantidad: 1 },
        { codigo: 102, nombre: 'Mouse Gamer', precio: 10000, cantidad: 1 }
      ];
      localStorage.setItem('carritoGamer', JSON.stringify(carritoMock));

      window.eliminarDelCarrito(0);

      const carritoActualizado = JSON.parse(localStorage.getItem('carritoGamer'));
      expect(carritoActualizado.length).toBe(1);
      expect(carritoActualizado[0].nombre).toBe('Mouse Gamer');
    });

    it('8. Debe aplicar un 20% de descuento al total si el usuario es de Duoc (@duocuc.cl)', () => {
      const usuarioDuoc = { correo: 'estudiante@duocuc.cl' };
      const carritoMock = [{ codigo: 101, nombre: 'Teclado Gamer', precio: 20000, cantidad: 1 }];

      localStorage.setItem('usuarioActivo', JSON.stringify(usuarioDuoc));
      localStorage.setItem('carritoGamer', JSON.stringify(carritoMock));

      window.cargarCarrito();

      expect(document.getElementById('cart-total').innerText).toBe('16.000');
    });

  });


  //  PRUEBAS DE VISUALIZACIÓN DE CARRITO 

  describe('3. Visualización y Modales del Carrito (script_carrito.js)', () => {

    it('9. Debe mostrar el mensaje de "Tu carrito está vacío" cuando no hay productos', () => {
      localStorage.setItem('carritoGamer', JSON.stringify([]));

      window.cargarCarrito();

      const contenedor = document.getElementById('cart-container');
      const total = document.getElementById('cart-total');

      expect(contenedor.innerHTML).toContain('Tu carrito está vacío');
      expect(total.innerText).toBe('0');
    });

    it('10. Debe desplegar correctamente el modal de confirmación con los textos y estilos asignados', () => {
      window.abrirModalConfirmacion(
        "¿Confirmas vaciar el carrito?",
        "⚠️",
        "Vaciar",
        "#ff3333",
        "white",
        null,
        false
      );

      const modal = document.getElementById('modal-confirmacion');
      const mensaje = document.getElementById('modal-mensaje');
      const btnConfirmar = document.getElementById('btn-confirmar-accion');

      expect(modal.style.display).toBe('flex');
      expect(mensaje.innerText).toBe('¿Confirmas vaciar el carrito?');
      expect(btnConfirmar.innerText).toBe('Vaciar');
      expect(btnConfirmar.style.backgroundColor).toBe('rgb(255, 51, 51)');
    });

  });

});